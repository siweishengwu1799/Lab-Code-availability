import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ==================== 1. 读取数据 ====================
file_path = 'OR1A2、OR5A1、OR5M3、OR10G4-all-MD-top20.xlsx'
df = pd.read_excel(file_path, sheet_name='8OR')

print("数据形状:", df.shape)
print("标签分布:\n", df['标签（Y）'].value_counts())

# ==================== 2. 提取特征和标签 ====================
y = df['标签（Y）'].values
feature_cols = [col for col in df.columns if col not in ['Name', '标签（Y）']]
X = df[feature_cols].copy()

# 检查缺失值
print("缺失值数量:", X.isnull().sum().sum())
if X.isnull().sum().sum() > 0:
    X = X.fillna(X.median())

# ==================== 3. 随机森林 + LOOCV ====================
rf = RandomForestClassifier(n_estimators=100, max_depth=5, min_samples_split=3,
                            random_state=42, class_weight='balanced')
loo = LeaveOneOut()
y_pred = cross_val_predict(rf, X, y, cv=loo)

# ==================== 4. 评估 ====================
acc = accuracy_score(y, y_pred)
cm = confusion_matrix(y, y_pred)
report = classification_report(y, y_pred, target_names=['JT(焦甜)', 'QT(清甜)'])

print("\n" + "="*60)
print("随机森林 + 留一法交叉验证结果")
print("="*60)
print(f"准确率: {acc:.3f}")
print("\n混淆矩阵:")
print(cm)
print("\n分类报告:")
print(report)

# ==================== 5. 输出预测错误的分子 ====================
pred_df = df[['Name', '标签（Y）']].copy()
pred_df['预测标签'] = y_pred
pred_df['是否正确'] = (pred_df['标签（Y）'] == pred_df['预测标签'])

errors = pred_df[~pred_df['是否正确']]
if len(errors) > 0:
    print("\n预测错误的分子:")
    print(errors[['Name', '标签（Y）', '预测标签']].to_string(index=False))
else:
    print("\n所有样本均预测正确！")

# ==================== 6. 输出特征重要性（在全部数据上训练最终模型） ====================
rf_final = RandomForestClassifier(n_estimators=100, max_depth=5, min_samples_split=3,
                                  random_state=42, class_weight='balanced')
rf_final.fit(X, y)
importances = rf_final.feature_importances_
feat_imp_df = pd.DataFrame({'特征': feature_cols, '重要性': importances})
feat_imp_df = feat_imp_df.sort_values('重要性', ascending=False)

print("\n" + "="*60)
print("特征重要性排序（Top 20）")
print("="*60)
print(feat_imp_df.head(20).to_string(index=False))