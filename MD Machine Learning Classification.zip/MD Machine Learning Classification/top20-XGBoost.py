import pandas as pd
import numpy as np
from xgboost import XGBClassifier          # 替换 SVC
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ==================== 1. 读取数据 ====================
file_path = 'OR1A2、OR5A1、OR5M3、OR10G4-all-MD-top20.xlsx'
df = pd.read_excel(file_path, sheet_name='8OR')

print("数据形状:", df.shape)
print("标签分布:\n", df['标签（Y）'].value_counts())

# ==================== 2. 提取特征和标签 ====================
y = df['标签（Y）'].values
feature_cols = [col for col in df.columns if col not in ['Name', '标签（Y）']]
X = df[feature_cols].copy()

# 缺失值处理（OR5M3-RMSD 存在空值，用中位数填充）
if X.isnull().sum().sum() > 0:
    print("存在缺失值，使用中位数填充。")
    X = X.fillna(X.median())

# ==================== 3. 标准化 ====================
# 注意：XGBoost 是树模型，对尺度不敏感，但保留标准化不会影响结果
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==================== 4. XGBoost + LOOCV ====================
# 替换 SVC 为 XGBClassifier，设置二分类参数
xgb = XGBClassifier(
    n_estimators=100,                # 树的数量
    learning_rate=0.1,               # 学习率
    max_depth=5,                     # 树的最大深度
    objective='binary:logistic',     # 二分类目标
    random_state=42,
    eval_metric='logloss'            # 评估指标（不影响预测）
)
loo = LeaveOneOut()
y_pred = cross_val_predict(xgb, X_scaled, y, cv=loo)

# ==================== 5. 评估 ====================
acc = accuracy_score(y, y_pred)
cm = confusion_matrix(y, y_pred)
report = classification_report(y, y_pred, target_names=['JT(焦甜)', 'QT(清甜)'])

print("\n" + "="*60)
print("XGBoost + 留一法交叉验证结果")
print("="*60)
print(f"准确率: {acc:.3f}")
print("\n混淆矩阵:")
print(cm)
print("\n分类报告:")
print(report)

# ==================== 6. 错误预测分子 ====================
pred_df = df[['Name', '标签（Y）']].copy()
pred_df['预测标签'] = y_pred
pred_df['是否正确'] = (pred_df['标签（Y）'] == pred_df['预测标签'])

errors = pred_df[~pred_df['是否正确']]
if len(errors) > 0:
    print("\n预测错误的分子:")
    print(errors[['Name', '标签（Y）', '预测标签']].to_string(index=False))
else:
    print("\n所有样本均预测正确！")