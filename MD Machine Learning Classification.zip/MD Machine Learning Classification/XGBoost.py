import pandas as pd
import numpy as np
from xgboost import XGBClassifier          # 替换 SVC
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ==================== 1. 读取数据 ====================
file_path = 'OR1A2、OR5A1、OR5M3、OR10G4-all-MD.xlsx'
df = pd.read_excel(file_path, sheet_name='8OR')

print("数据形状:", df.shape)
print("标签分布:\n", df['标签（Y）'].value_counts())

# ==================== 2. 提取特征和标签 ====================
y = df['标签（Y）'].values
feature_cols = [col for col in df.columns if col not in ['Name', '标签（Y）']]
X = df[feature_cols].copy()

# 检查缺失值
print("缺失值数量:", X.isnull().sum().sum())
if X.isnull().sum().sum() > 0:
    X = X.fillna(X.median())  # 中位数填充

# ==================== 3. 特征标准化（XGBoost 对尺度不敏感，但保留无妨） ====================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==================== 4. XGBoost + 留一法交叉验证 ====================
# 设置 XGBoost 二分类器，使用常用默认参数，添加随机种子以保证可重复性
xgb = XGBClassifier(
    n_estimators=100,          # 树的数量
    learning_rate=0.1,         # 学习率
    max_depth=5,               # 树的最大深度
    objective='binary:logistic',  # 二分类目标
    random_state=42,
    eval_metric='logloss'      # 评估指标
)
loo = LeaveOneOut()
y_pred = cross_val_predict(xgb, X_scaled, y, cv=loo)

# ==================== 5. 模型评估 ====================
acc = accuracy_score(y, y_pred)
cm = confusion_matrix(y, y_pred)
report = classification_report(y, y_pred, target_names=['JT(焦甜)', 'QT(清甜)'])

print("\n" + "="*60)
print("XGBoost + 留一法交叉验证结果")
print("="*60)
print(f"准确率: {acc:.3f}")
print("\n混淆矩阵:")
print(cm)
print("\n分类报告:")
print(report)

# ==================== 6. 输出预测错误的分子 ====================
pred_df = df[['Name', '标签（Y）']].copy()
pred_df['预测标签'] = y_pred
pred_df['是否正确'] = (pred_df['标签（Y）'] == pred_df['预测标签'])

errors = pred_df[~pred_df['是否正确']]
if len(errors) > 0:
    print("\n预测错误的分子:")
    print(errors[['Name', '标签（Y）', '预测标签']].to_string(index=False))
else:
    print("\n所有样本均预测正确！")

# ==================== 7. （可选）XGBoost 超参数网格搜索 ====================
# 若需要调参，可开启以下代码
"""
from sklearn.model_selection import GridSearchCV
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.1, 0.2]
}
grid = GridSearchCV(
    XGBClassifier(objective='binary:logistic', random_state=42, eval_metric='logloss'),
    param_grid,
    cv=loo,
    scoring='accuracy'
)
grid.fit(X_scaled, y)
print("最优XGBoost参数:", grid.best_params_)
y_pred_xgb = cross_val_predict(grid.best_estimator_, X_scaled, y, cv=loo)
acc_xgb = accuracy_score(y, y_pred_xgb)
print(f"调优后XGBoost准确率: {acc_xgb:.3f}")
"""