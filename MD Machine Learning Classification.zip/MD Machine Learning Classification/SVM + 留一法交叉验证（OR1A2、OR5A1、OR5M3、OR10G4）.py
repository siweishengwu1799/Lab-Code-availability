import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import LeaveOneOut, cross_val_predict
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# ==================== 1. 读取数据 ====================
file_path = 'OR1A2、OR5A1、OR5M3、OR10G4-all-MD.xlsx'
df = pd.read_excel(file_path, sheet_name='8OR')

print("数据形状:", df.shape)
print("标签分布:\n", df['标签（Y）'].value_counts())

# ==================== 2. 提取特征和标签 ====================
y = df['标签（Y）'].values
feature_cols = [col for col in df.columns if col not in ['Name', '标签（Y）']]
X = df[feature_cols].copy()

# 检查缺失值
print("缺失值数量:", X.isnull().sum().sum())
if X.isnull().sum().sum() > 0:
    X = X.fillna(X.median())  # 中位数填充

# ==================== 3. 特征标准化 ====================
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==================== 4. SVM + 留一法交叉验证 ====================
# 使用线性核（可解释性强）
svm = SVC(kernel='linear', C=1.0, random_state=42)
loo = LeaveOneOut()
y_pred = cross_val_predict(svm, X_scaled, y, cv=loo)

# ==================== 5. 模型评估 ====================
acc = accuracy_score(y, y_pred)
cm = confusion_matrix(y, y_pred)
report = classification_report(y, y_pred, target_names=['JT(焦甜)', 'QT(清甜)'])

print("\n" + "="*60)
print("SVM + 留一法交叉验证结果")
print("="*60)
print(f"准确率: {acc:.3f}")
print("\n混淆矩阵:")
print(cm)
print("\n分类报告:")
print(report)

# ==================== 6. 输出预测错误的分子 ====================
pred_df = df[['Name', '标签（Y）']].copy()
pred_df['预测标签'] = y_pred
pred_df['是否正确'] = (pred_df['标签（Y）'] == pred_df['预测标签'])

errors = pred_df[~pred_df['是否正确']]
if len(errors) > 0:
    print("\n预测错误的分子:")
    print(errors[['Name', '标签（Y）', '预测标签']].to_string(index=False))
else:
    print("\n所有样本均预测正确！")

# ==================== 7. （可选）RBF核网格搜索 ====================
# 若线性核效果不佳，可尝试RBF核并调参
"""
from sklearn.model_selection import GridSearchCV
param_grid = {'C': [0.1, 1, 10, 100], 'gamma': ['scale', 'auto']}
grid = GridSearchCV(SVC(kernel='rbf', random_state=42), param_grid, cv=loo, scoring='accuracy')
grid.fit(X_scaled, y)
print("最优RBF参数:", grid.best_params_)
y_pred_rbf = cross_val_predict(grid.best_estimator_, X_scaled, y, cv=loo)
acc_rbf = accuracy_score(y, y_pred_rbf)
print(f"RBF SVM 准确率: {acc_rbf:.3f}")
"""