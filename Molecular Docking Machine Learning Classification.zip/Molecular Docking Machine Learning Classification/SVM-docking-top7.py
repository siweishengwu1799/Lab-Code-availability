#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SVM模型区分焦甜/清甜物质（线性核）
基于分子对接数据的留一交叉验证
功能：性能评估、错误分子输出、特征权重、可视化图表
【已修正】标签定义：0=焦甜(JT)，1=清甜(QT)，与原始数据集完全对应
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings

warnings.filterwarnings('ignore')

# ==================== 配置参数 ====================
DATA_FILE = 'OR1A2-OR5A1-OR5M3-OR10G4-top7-docking.xlsx'
SHEET_NAME = 'Sheet1'
OUTPUT_DIR = './output/'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# SVM参数（线性核，可输出特征权重）
SVM_KERNEL = 'linear'
SVM_C = 1.0
RANDOM_STATE = 42

# 中文字体设置
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# ==================== 1. 读取数据 ====================
print("=" * 80)
print("SVM模型训练 - 区分焦甜/清甜物质 (线性核)")
print("标签定义：0 = 焦甜(JT)，1 = 清甜(QT)")
print("=" * 80)

df = pd.read_excel(DATA_FILE, sheet_name=SHEET_NAME)

required_cols = ['Name', '标签（Y）']
if not all(col in df.columns for col in required_cols):
    raise ValueError("数据中缺少 'Name' 或 '标签（Y）' 列！")

print(f"\n数据维度: {df.shape}")
print(f"列名: {df.columns.tolist()}")
print(f"\n标签分布:")
print(df['标签（Y）'].value_counts())

# ==================== 2. 准备特征和标签 ====================
feature_cols = [col for col in df.columns if col not in ['Name', '标签（Y）']]
print(f"\n使用的特征列: {feature_cols}")

X = df[feature_cols].values
y = df['标签（Y）'].values
names = df['Name'].values

print(f"\n样本总数: {len(y)}")
print(f"焦甜(JT, 标签0): {(y == 0).sum()} 个")
print(f"清甜(QT, 标签1): {(y == 1).sum()} 个")
print(f"特征数: {X.shape[1]}")

# ==================== 3. 留一交叉验证 ====================
print(f"\n{'=' * 80}")
print("留一交叉验证 (Leave-One-Out)")
print(f"{'=' * 80}")

loo = LeaveOneOut()
predictions = []

for i, (train_idx, test_idx) in enumerate(loo.split(X)):
    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]
    name_test = names[test_idx][0]

    # 标准化：仅训练集拟合，测试集转换，杜绝数据泄露
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 训练线性SVM
    svm = SVC(kernel=SVM_KERNEL, C=SVM_C, probability=True, random_state=RANDOM_STATE)
    svm.fit(X_train_scaled, y_train)

    # 预测
    pred = svm.predict(X_test_scaled)[0]
    proba = svm.predict_proba(X_test_scaled)[0]

    predictions.append({
        'name': name_test,
        'true': y_test[0],
        'pred': pred,
        'proba_jt': proba[0],   # 标签0：焦甜概率
        'proba_qt': proba[1],   # 标签1：清甜概率
        'correct': pred == y_test[0]
    })

    if (i + 1) % 10 == 0 or i == 0:
        print(f"  已完成 {i + 1}/{len(y)} 次迭代...")

results_df = pd.DataFrame(predictions)

# ==================== 4. 计算性能指标 ====================
true_labels = results_df['true'].values
predicted_labels = results_df['pred'].values

accuracy = accuracy_score(true_labels, predicted_labels)

print(f"\n{'=' * 80}")
print("总体结果")
print(f"{'=' * 80}")
print(f"留一交叉验证准确率: {accuracy * 100:.2f}% "
      f"({(true_labels == predicted_labels).sum()}/{len(y)})")

# 混淆矩阵
cm = confusion_matrix(true_labels, predicted_labels)
print(f"\n{'=' * 80}")
print("混淆矩阵（行=真实标签，列=预测标签）")
print(f"{'=' * 80}")
print(f"              预测焦甜(0)  预测清甜(1)")
print(f"实际焦甜(0)      {cm[0, 0]:3d}         {cm[0, 1]:3d}")
print(f"实际清甜(1)      {cm[1, 0]:3d}         {cm[1, 1]:3d}")

# 分类报告
print(f"\n{'=' * 80}")
print("分类报告")
print(f"{'=' * 80}")
print(classification_report(true_labels, predicted_labels,
                            target_names=['焦甜(JT)', '清甜(QT)']))

# ==================== 5. 预测错误的分子 ====================
errors = results_df[~results_df['correct']].copy()
errors['真实标签'] = errors['true'].map({0: '焦甜', 1: '清甜'})
errors['预测标签'] = errors['pred'].map({0: '焦甜', 1: '清甜'})

print(f"\n{'=' * 80}")
print("预测错误的分子")
print(f"{'=' * 80}")
if len(errors) > 0:
    print(f"\n共 {len(errors)} 个分子预测错误:\n")
    for idx, row in errors.iterrows():
        confidence = row['proba_jt'] if row['pred'] == 0 else row['proba_qt']
        print(f"  {row['name']:6s} | 真实: {row['真实标签']:4s} | "
              f"预测: {row['预测标签']:4s} | 置信度: {confidence:.3f}")

    # 错误分子详细特征
    print(f"\n错误分子的详细特征:")
    error_names = errors['name'].tolist()
    error_data = df[df['Name'].isin(error_names)].copy()
    error_data['真实标签'] = error_data['标签（Y）'].map({0: '焦甜', 1: '清甜'})
    error_data = error_data.merge(
        errors[['name', 'pred']],
        left_on='Name', right_on='name', how='left'
    )
    error_data['预测标签'] = error_data['pred'].map({0: '焦甜', 1: '清甜'})
    display_cols = ['Name', '真实标签', '预测标签'] + feature_cols
    print(error_data[display_cols].to_string(index=False))
else:
    print("\n所有样本预测正确！")

# ==================== 6. 全量训练模型 + 特征权重 ====================
print(f"\n{'=' * 80}")
print("训练最终模型（全部数据）并输出特征权重")
print(f"{'=' * 80}")

scaler_final = StandardScaler()
X_scaled = scaler_final.fit_transform(X)

svm_final = SVC(kernel='linear', C=SVM_C, random_state=RANDOM_STATE)
svm_final.fit(X_scaled, y)

# 线性SVM权重系数：正数越大越偏向清甜(1)，负数越大越偏向焦甜(0)
coef = svm_final.coef_[0]
feature_importance = pd.DataFrame({
    '特征名称': feature_cols,
    '权重系数': coef,
    '权重绝对值': np.abs(coef)
}).sort_values('权重绝对值', ascending=False)

print(f"\n特征权重排序（绝对值越大，对分类贡献越高）:")
print("【说明】权重为正：特征值越大，越倾向判定为清甜；权重为负：特征值越大，越倾向判定为焦甜")
print(feature_importance[['特征名称', '权重系数', '权重绝对值']].to_string(index=False))

# ==================== 7. 可视化图表 ====================
print(f"\n生成可视化图表...")

fig, axes = plt.subplots(2, 2, figsize=(14, 12))

# 图1：特征权重水平条形图
ax1 = axes[0, 0]
imp_sort = feature_importance.sort_values('权重绝对值', ascending=True)
ax1.barh(imp_sort['特征名称'], imp_sort['权重绝对值'], color='steelblue')
ax1.set_xlabel('权重绝对值')
ax1.set_title('特征重要性（线性SVM权重绝对值）')
ax1.grid(axis='x', alpha=0.3)

# 图2：混淆矩阵热力图
ax2 = axes[0, 1]
im = ax2.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
ax2.figure.colorbar(im, ax=ax2)
ax2.set_xticks([0, 1])
ax2.set_yticks([0, 1])
ax2.set_xticklabels(['预测：焦甜', '预测：清甜'])
ax2.set_yticklabels(['真实：焦甜', '真实：清甜'])
ax2.set_xlabel('预测标签')
ax2.set_ylabel('真实标签')
ax2.set_title('混淆矩阵')
for i in range(2):
    for j in range(2):
        ax2.text(j, i, f"{cm[i, j]}", ha="center", va="center",
                 color="white" if cm[i, j] > cm.max() / 2 else "black",
                 fontsize=16, fontweight='bold')

# 图3：预测概率分布
ax3 = axes[1, 0]
jt_proba = results_df[results_df['true'] == 0]['proba_qt'].values  # 焦甜样本被判定为清甜的概率
qt_proba = results_df[results_df['true'] == 1]['proba_qt'].values  # 清甜样本被判定为清甜的概率
ax3.hist(jt_proba, bins=15, alpha=0.6, label='实际焦甜(JT)', color='lightcoral', edgecolor='red')
ax3.hist(qt_proba, bins=15, alpha=0.6, label='实际清甜(QT)', color='lightblue', edgecolor='blue')
ax3.axvline(0.5, color='black', linestyle='--', label='决策边界(0.5)')
ax3.set_xlabel('预测为清甜(QT)的概率')
ax3.set_ylabel('样本数')
ax3.set_title('两类分子预测概率分布')
ax3.legend()

# 图4：权重最高特征的分布 + 错误样本标记
top_feature = feature_importance.iloc[0]['特征名称']
ax4 = axes[1, 1]
if top_feature in df.columns:
    jt_vals = df[df['标签（Y）'] == 0][top_feature].values
    qt_vals = df[df['标签（Y）'] == 1][top_feature].values
    ax4.hist(jt_vals, bins=12, alpha=0.5, label='焦甜(JT)', color='lightcoral', edgecolor='red')
    ax4.hist(qt_vals, bins=12, alpha=0.5, label='清甜(QT)', color='lightblue', edgecolor='blue')
    # 标记错误预测样本
    for idx in errors.index:
        name = errors.loc[idx, 'name']
        val = df[df['Name'] == name][top_feature].values[0]
        true_label = errors.loc[idx, 'true']
        color = 'red' if true_label == 0 else 'blue'
        ax4.axvline(val, color=color, linestyle='--', alpha=0.6, linewidth=1.5)
    ax4.set_xlabel(top_feature)
    ax4.set_ylabel('样本数')
    ax4.set_title(f'{top_feature} 分布（虚线为错误预测样本）')
    ax4.legend()
else:
    ax4.text(0.5, 0.5, '特征列不存在', ha='center', va='center', transform=ax4.transAxes)
    ax4.set_title('无法显示')

plt.tight_layout()
plot_file = os.path.join(OUTPUT_DIR, 'SVM_线性核_焦甜清甜分类分析.png')
plt.savefig(plot_file, dpi=150, bbox_inches='tight')
print(f"图表已保存: {plot_file}")
plt.show()

# ==================== 8. 保存结果文件 ====================
print(f"\n保存结果文件...")
results_df.to_csv(os.path.join(OUTPUT_DIR, 'SVM_LOOCV全样本预测结果.csv'), index=False, encoding='utf-8-sig')
if len(errors) > 0:
    errors_out = errors[['name', '真实标签', '预测标签', 'proba_jt', 'proba_qt']].copy()
    errors_out.columns = ['分子名称', '真实类别', '预测类别', '焦甜概率', '清甜概率']
    errors_out.to_csv(os.path.join(OUTPUT_DIR, 'SVM_预测错误分子清单.csv'),
                      index=False, encoding='utf-8-sig')
print(f"结果文件已保存至: {OUTPUT_DIR} 目录")

# ==================== 9. 最终总结报告 ====================
print(f"\n{'=' * 80}")
print("最终总结报告")
print(f"{'=' * 80}")

jt_precision = cm[0, 0] / (cm[0, 0] + cm[1, 0]) if (cm[0, 0] + cm[1, 0]) > 0 else 0
jt_recall = cm[0, 0] / (cm[0, 0] + cm[0, 1]) if (cm[0, 0] + cm[0, 1]) > 0 else 0
qt_precision = cm[1, 1] / (cm[1, 1] + cm[0, 1]) if (cm[1, 1] + cm[0, 1]) > 0 else 0
qt_recall = cm[1, 1] / (cm[1, 1] + cm[1, 0]) if (cm[1, 1] + cm[1, 0]) > 0 else 0

print(f"""
【模型配置】
  - 算法: SVM (线性核)
  - 正则系数 C = {SVM_C}
  - 验证方式: 留一交叉验证 (LOO)
  - 标签定义: 0=焦甜(JT)，1=清甜(QT)

【整体性能】
  - 总准确率: {accuracy * 100:.2f}% ({(true_labels == predicted_labels).sum()}/{len(y)})
  - 焦甜(JT) 精确率: {jt_precision * 100:.1f}% | 召回率: {jt_recall * 100:.1f}%
  - 清甜(QT) 精确率: {qt_precision * 100:.1f}% | 召回率: {qt_recall * 100:.1f}%

【核心区分特征 Top1】
  {feature_importance.iloc[0]['特征名称']}
  权重系数: {feature_importance.iloc[0]['权重系数']:.3f}
  权重绝对值: {feature_importance.iloc[0]['权重绝对值']:.3f}

【错误分子统计】
  - 焦甜误判为清甜: {len(errors[(errors['true'] == 0) & (errors['pred'] == 1)])} 个
  - 清甜误判为焦甜: {len(errors[(errors['true'] == 1) & (errors['pred'] == 0)])} 个
""")

print("=" * 80)
print("运行完成！")
print("=" * 80)