#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SVM模型区分 caramel-like (CS) / fresh-sweet (FS) 物质（线性核）
基于分子对接数据的留一交叉验证
功能：性能评估、错误分子输出、特征权重、可视化图表
标签定义：0 = CS (caramel-like)，1 = FS (fresh-sweet)
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import LeaveOneOut
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings

warnings.filterwarnings('ignore')

# ==================== 配置参数 ====================
DATA_FILE = 'OR1A2-OR5A1-OR5M3-OR10G4-top7-docking.xlsx'
SHEET_NAME = 'Sheet1'
OUTPUT_DIR = './output/'
os.makedirs(OUTPUT_DIR, exist_ok=True)

SVM_KERNEL = 'linear'
SVM_C = 1.0
RANDOM_STATE = 42

# ==================== 1. 读取数据 ====================
print("=" * 80)
print("SVM模型训练 - 区分 caramel-like / fresh-sweet 物质 (线性核)")
print("标签定义：0 = CS (caramel-like)，1 = FS (fresh-sweet)")
print("=" * 80)

df = pd.read_excel(DATA_FILE, sheet_name=SHEET_NAME)

required_cols = ['Name', 'Sensory label (Y)']
if not all(col in df.columns for col in required_cols):
    raise ValueError("数据中缺少 'Name' 或 'Sensory label (Y)' 列！")

print(f"\n数据维度: {df.shape}")
print(f"列名: {df.columns.tolist()}")
print(f"\n标签分布:")
print(df['Sensory label (Y)'].value_counts())

feature_cols = [col for col in df.columns if col not in ['Name', 'Sensory label (Y)']]
print(f"\n使用的特征列: {feature_cols}")

X = df[feature_cols].values
y = df['Sensory label (Y)'].values
names = df['Name'].values

print(f"\n样本总数: {len(y)}")
print(f"CS (caramel-like, 标签0): {(y == 0).sum()} 个")
print(f"FS (fresh-sweet, 标签1): {(y == 1).sum()} 个")
print(f"特征数: {X.shape[1]}")

# ==================== 2. 留一交叉验证 ====================
print(f"\n{'=' * 80}")
print("留一交叉验证 (Leave-One-Out)")
print(f"{'=' * 80}")

loo = LeaveOneOut()
predictions = []

for i, (train_idx, test_idx) in enumerate(loo.split(X)):
    X_train, X_test = X[train_idx], X[test_idx]
    y_train, y_test = y[train_idx], y[test_idx]
    name_test = names[test_idx][0]

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    svm = SVC(kernel=SVM_KERNEL, C=SVM_C, probability=True, random_state=RANDOM_STATE)
    svm.fit(X_train_scaled, y_train)

    pred = svm.predict(X_test_scaled)[0]
    proba = svm.predict_proba(X_test_scaled)[0]

    predictions.append({
        'name': name_test,
        'true': y_test[0],
        'pred': pred,
        'proba_cs': proba[0],
        'proba_fs': proba[1],
        'correct': pred == y_test[0]
    })

    if (i + 1) % 10 == 0 or i == 0:
        print(f"  已完成 {i + 1}/{len(y)} 次迭代...")

results_df = pd.DataFrame(predictions)

# ==================== 3. 计算性能指标 ====================
true_labels = results_df['true'].values
predicted_labels = results_df['pred'].values
accuracy = accuracy_score(true_labels, predicted_labels)

print(f"\n{'=' * 80}")
print("总体结果")
print(f"{'=' * 80}")
print(f"留一交叉验证准确率: {accuracy * 100:.2f}% "
      f"({(true_labels == predicted_labels).sum()}/{len(y)})")

cm = confusion_matrix(true_labels, predicted_labels)
print(f"\n{'=' * 80}")
print("混淆矩阵（行=真实标签，列=预测标签）")
print(f"{'=' * 80}")
print(f"              预测 CS(0)  预测 FS(1)")
print(f"实际 CS(0)      {cm[0, 0]:3d}         {cm[0, 1]:3d}")
print(f"实际 FS(1)      {cm[1, 0]:3d}         {cm[1, 1]:3d}")

print(f"\n{'=' * 80}")
print("分类报告")
print(f"{'=' * 80}")
print(classification_report(true_labels, predicted_labels,
                            target_names=['CS (caramel-like)', 'FS (fresh-sweet)']))

# ==================== 4. 预测错误的分子 ====================
errors = results_df[~results_df['correct']].copy()
errors['真实标签'] = errors['true'].map({0: 'CS', 1: 'FS'})
errors['预测标签'] = errors['pred'].map({0: 'CS', 1: 'FS'})

print(f"\n{'=' * 80}")
print("预测错误的分子")
print(f"{'=' * 80}")
if len(errors) > 0:
    print(f"\n共 {len(errors)} 个分子预测错误:\n")
    for idx, row in errors.iterrows():
        confidence = row['proba_cs'] if row['pred'] == 0 else row['proba_fs']
        print(f"  {row['name']:6s} | 真实: {row['真实标签']:4s} | "
              f"预测: {row['预测标签']:4s} | 置信度: {confidence:.3f}")

    print(f"\n错误分子的详细特征:")
    error_names = errors['name'].tolist()
    error_data = df[df['Name'].isin(error_names)].copy()
    error_data['真实标签'] = error_data['Sensory label (Y)'].map({0: 'CS', 1: 'FS'})
    error_data = error_data.merge(
        errors[['name', 'pred']],
        left_on='Name', right_on='name', how='left'
    )
    error_data['预测标签'] = error_data['pred'].map({0: 'CS', 1: 'FS'})
    display_cols = ['Name', '真实标签', '预测标签'] + feature_cols
    print(error_data[display_cols].to_string(index=False))
else:
    print("\n所有样本预测正确！")

# ==================== 5. 全量训练模型 + 特征权重 ====================
print(f"\n{'=' * 80}")
print("训练最终模型（全部数据）并输出特征权重")
print(f"{'=' * 80}")

scaler_final = StandardScaler()
X_scaled = scaler_final.fit_transform(X)

svm_final = SVC(kernel='linear', C=SVM_C, random_state=RANDOM_STATE)
svm_final.fit(X_scaled, y)

coef = svm_final.coef_[0]
feature_importance = pd.DataFrame({
    '特征名称': feature_cols,
    '权重系数': coef,
    '权重绝对值': np.abs(coef)
}).sort_values('权重绝对值', ascending=False)

print(f"\n特征权重排序（绝对值越大，对分类贡献越高）:")
print("【说明】权重为正：特征值越大，越倾向判定为FS；权重为负：特征值越大，越倾向判定为CS")
print(feature_importance[['特征名称', '权重系数', '权重绝对值']].to_string(index=False))

# ==================== 6. 可视化图表（含频数标注） ====================
print(f"\n生成可视化图表...")

# ---------- 全局绘图参数设置 ----------
inch_per_mm = 1 / 25.4
width_inch = 89 * inch_per_mm          # 单栏宽度 89 mm

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 10
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['axes.linewidth'] = 1.0
plt.rcParams['grid.linewidth'] = 0.8
plt.rcParams['lines.linewidth'] = 1.0

color_cs = '#FE9F69'   # 暖橘橙（柱身颜色，保持不变）
color_fs = '#8EBCDB'   # 浅天蓝（柱身颜色，保持不变）
# 柱顶数字专用深色（加深对比度）
color_cs_text = '#D55E00'   # 深橙色
color_fs_text = '#0072B2'   # 深蓝色

# ----- 图1：混淆矩阵（宽89mm，高80mm，与图2比例一致） -----
fig1 = plt.figure(figsize=(width_inch, 80 * inch_per_mm))   # ★ 高度由 100mm 改为 80mm
ax1 = fig1.add_subplot(111)
im = ax1.imshow(cm, interpolation='nearest', cmap='Blues', vmin=0, vmax=np.max(cm)+1)
cbar = plt.colorbar(im, ax=ax1, fraction=0.046, pad=0.04)
cbar.ax.tick_params(labelsize=10)

ax1.set_xticks([0, 1])
ax1.set_yticks([0, 1])
ax1.set_xticklabels(['Predicted CS', 'Predicted FS'], fontsize=10)
ax1.set_yticklabels(['Actual CS', 'Actual FS'], fontsize=10)
ax1.set_xlabel('Predicted label', fontsize=12, labelpad=2)
ax1.set_ylabel('Actual label', fontsize=12, labelpad=2)

for i in range(2):
    for j in range(2):
        ax1.text(j, i, f"{cm[i, j]}", ha="center", va="center",
                 color="white" if cm[i, j] > cm.max()/2 else "black",
                 fontsize=10, fontweight='bold')

ax1.set_title('')
plt.tight_layout()

tiff_file1 = os.path.join(OUTPUT_DIR, 'Confusion_matrix.tiff')
try:
    plt.savefig(tiff_file1, dpi=300, format='tiff', pil_kwargs={'compression': 'tiff_lzw'})
except Exception:
    plt.savefig(tiff_file1, dpi=300, format='tiff')
plt.show()
plt.close(fig1)
print(f"混淆矩阵图已保存: {tiff_file1}")

# ----- 图2：概率分布 (宽89mm，高80mm) 含频数标注 -----
fig2 = plt.figure(figsize=(width_inch, 80 * inch_per_mm))
ax2 = fig2.add_subplot(111)

cs_proba = results_df[results_df['true'] == 0]['proba_fs'].values
fs_proba = results_df[results_df['true'] == 1]['proba_fs'].values

bins = np.linspace(0, 1, 12)
# 绘制直方图并返回频数
n_cs, bins_cs, patches_cs = ax2.hist(cs_proba, bins=bins, alpha=0.7, label='Actual CS',
                                      color=color_cs, edgecolor='black', linewidth=0.8)
n_fs, bins_fs, patches_fs = ax2.hist(fs_proba, bins=bins, alpha=0.7, label='Actual FS',
                                      color=color_fs, edgecolor='black', linewidth=0.8)

# 标注频数（柱顶上方），数字颜色改为深橙 / 深蓝
bin_centers = (bins[:-1] + bins[1:]) / 2
offset = (bins[1] - bins[0]) * 0.05
for x, count in zip(bin_centers, n_cs.astype(int)):
    if count > 0:
        ax2.text(x - offset, count + 0.1, str(count), ha='center', va='bottom',
                 fontsize=9, color=color_cs_text, fontweight='bold')   # 深橙 + 加粗
for x, count in zip(bin_centers, n_fs.astype(int)):
    if count > 0:
        ax2.text(x + offset, count + 0.1, str(count), ha='center', va='bottom',
                 fontsize=9, color=color_fs_text, fontweight='bold')   # 深蓝 + 加粗

# 决策边界
ax2.axvline(0.5, color='black', linestyle='--', linewidth=0.8)

ax2.set_xlabel('Predicted probability of FS', fontsize=12)
ax2.set_ylabel('Number of samples', fontsize=12)
ax2.tick_params(axis='both', labelsize=10)
ax2.legend(loc='upper left', fontsize=10, frameon=False)

for spine in ax2.spines.values():
    spine.set_linewidth(1.0)

ax2.set_title('')
# 调整y轴上限为最大频数的1.2倍，为标注预留空间
ymax = max(np.max(n_cs), np.max(n_fs)) * 1.2
if ymax == 0:
    ymax = 1
ax2.set_ylim(0, ymax)

plt.tight_layout()

tiff_file2 = os.path.join(OUTPUT_DIR, 'Probability_distribution.tiff')
try:
    plt.savefig(tiff_file2, dpi=300, format='tiff', pil_kwargs={'compression': 'tiff_lzw'})
except Exception:
    plt.savefig(tiff_file2, dpi=300, format='tiff')
plt.show()
plt.close(fig2)
print(f"概率分布图已保存: {tiff_file2}")

# ==================== 7. 保存结果文件 ====================
print(f"\n保存结果文件...")
results_df.to_csv(os.path.join(OUTPUT_DIR, 'SVM_LOOCV全样本预测结果.csv'), index=False, encoding='utf-8-sig')
if len(errors) > 0:
    errors_out = errors[['name', '真实标签', '预测标签', 'proba_cs', 'proba_fs']].copy()
    errors_out.columns = ['分子名称', '真实类别', '预测类别', 'CS概率', 'FS概率']
    errors_out.to_csv(os.path.join(OUTPUT_DIR, 'SVM_预测错误分子清单.csv'),
                      index=False, encoding='utf-8-sig')
print(f"结果文件已保存至: {OUTPUT_DIR} 目录")

# ==================== 8. 最终总结报告 ====================
print(f"\n{'=' * 80}")
print("最终总结报告")
print(f"{'=' * 80}")

cs_precision = cm[0, 0] / (cm[0, 0] + cm[1, 0]) if (cm[0, 0] + cm[1, 0]) > 0 else 0
cs_recall = cm[0, 0] / (cm[0, 0] + cm[0, 1]) if (cm[0, 0] + cm[0, 1]) > 0 else 0
fs_precision = cm[1, 1] / (cm[1, 1] + cm[0, 1]) if (cm[1, 1] + cm[0, 1]) > 0 else 0
fs_recall = cm[1, 1] / (cm[1, 1] + cm[1, 0]) if (cm[1, 1] + cm[1, 0]) > 0 else 0

print(f"""
【模型配置】
  - 算法: SVM (线性核)
  - 正则系数 C = {SVM_C}
  - 验证方式: 留一交叉验证 (LOO)
  - 标签定义: 0=CS (caramel-like)，1=FS (fresh-sweet)

【整体性能】
  - 总准确率: {accuracy * 100:.2f}% ({(true_labels == predicted_labels).sum()}/{len(y)})
  - CS (caramel-like) 精确率: {cs_precision * 100:.1f}% | 召回率: {cs_recall * 100:.1f}%
  - FS (fresh-sweet)   精确率: {fs_precision * 100:.1f}% | 召回率: {fs_recall * 100:.1f}%

【核心区分特征 Top1】
  {feature_importance.iloc[0]['特征名称']}
  权重系数: {feature_importance.iloc[0]['权重系数']:.3f}
  权重绝对值: {feature_importance.iloc[0]['权重绝对值']:.3f}

【错误分子统计】
  - CS误判为FS: {len(errors[(errors['true'] == 0) & (errors['pred'] == 1)])} 个
  - FS误判为CS: {len(errors[(errors['true'] == 1) & (errors['pred'] == 0)])} 个
""")

print("=" * 80)
print("运行完成！")
print("=" * 80)